package com.mpc_group17.CanteenApp;

public class Canteen {

    private String name;
    private String rootURL;

    /**
     * Getters
     */
    public String getName() {
        return name;
    }

    public String getRootURL() {
        return rootURL;
    }

    /**
     * Setters
     */
    public void setName(String name) {
        this.name = name;
    }

    public void setRootURL(String rootURL) {
        this.rootURL = rootURL;
    }
}
